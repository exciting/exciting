#ifndef STO_INC
#define STO_INC

extern int stoi(char *s, int *dar);
extern int stod(char *s, double *dar);
extern int stos(char *s, char *s_out);
extern void print_dbl(char *text, int n, double *d);
#endif
